# test_gradio_simple.py
import gradio as gr

print("🎯 Тестирую Gradio...")

def echo(text):
    return f"Работает! Вы ввели: {text}"

demo = gr.Interface(
    fn=echo,
    inputs="text",
    outputs="text",
    title="Тест Gradio"
)

print("✅ Gradio работает!")
print("🌐 Открой http://localhost:7860")
demo.launch()